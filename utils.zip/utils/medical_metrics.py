import os
import cv2
import numpy as np
import time
from PIL import Image

def compute_iou(pred, target):
    # 将预测结果和标签转换为二进制格式
    pred = (pred > 128).astype(np.uint8)
    target = (target > 128).astype(np.uint8)

    # 计算交集和并集
    intersection = np.sum(pred * target)
    union = np.sum(pred) + np.sum(target) - intersection
    
    # 计算交并比
    iou = float(intersection) / float(union)
    
    return iou

# 计算Accuracy
def compute_accuracy(pred, target):
    # 将预测结果和标签转换为二进制格式
    pred = (pred > 128).astype(np.uint8)
    target = (target > 128).astype(np.uint8)
    
    # 计算相同的像素数
    correct_pixels = np.sum(np.equal(pred, target))
    
    # 计算总像素数
    total_pixels = pred.size
    
    # 计算Accuracy
    accuracy = float(correct_pixels) / float(total_pixels)
    
    return accuracy

# 计算Recall和Precision
def compute_recall_precision(pred, target):
    # 将预测结果和标签转换为二进制格式
    pred = (pred > 128).astype(np.uint8)
    target = (target > 128).astype(np.uint8)
    
    # 计算真正例、假正例和假反例的像素数
    tp = np.sum(np.logical_and(pred == 1, target == 1))
    fp = np.sum(np.logical_and(pred == 1, target == 0))
    fn = np.sum(np.logical_and(pred == 0, target == 1))
    
    # 计算Recall和Precision
    recall = float(tp) / float(tp + fn)
    precision = float(tp) / float(tp + fp)
    
    return recall, precision